
function NotFound() {
  return (
    <div>This Page Not Found</div>
  )
}

export default NotFound